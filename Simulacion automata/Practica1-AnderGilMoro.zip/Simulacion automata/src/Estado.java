public class Estado {
    private char nombre;

    public Estado (char nombre) {
        this.nombre = nombre;
    }
}
