Proyecto realizado por Ander Gil Moro. Autómata por vaciado de pila (Apv)

El código fuente se encuentra en la carpeta scr.

Para la utilización del autómata, se debe ejecutar la clase autómata. 
A continuación se deberá escribir el nombre del fichero que se quiera procesar: Apv.txt o Apv-2.txt.
Si se quiere procesar otro fichero, recordar que se debe encontrar en la carpeta del proyecto.
A continuación, solamente se tienen que escribir las cadenas que se quiera comprobar si pertenecen o no al lenguaje definido por el fichero.
Para finalizar la ejecución, escribir FIN.